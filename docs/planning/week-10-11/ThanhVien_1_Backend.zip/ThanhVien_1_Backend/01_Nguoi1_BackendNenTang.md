# Người 1 - Hoàn thành nền tảng trước khi người 2 nhận code

## Đầu vào và phạm vi

Nhận nguyên bộ contracts/ v1.0.0. Bạn sở hữu backend/ và handoff/member1.md. Chịu trách nhiệm toàn bộ cấu trúc DB ngay từ đầu; không chờ người 2 thiết kế hoặc gửi migration. Đọc database.md và OpenAPI, triển khai đúng tên/kiểu/enum.

## Task

- [ ] P1-01: Tạo repo/commit nền tảng contracts/ trên main và tag contract-v1.0.0; thông báo cho người 3/4 lấy commit này. Tạo nhánh member1/backend, làm code trong backend/.
- [ ] P1-02: Dựng Node.js 20 + Express 4, pg, bcrypt, JWT, xử lý lỗi, cấu hình và kết nối Supabase. Tạo package-lock.json, .env.example và .gitignore chặn .env/secret thật.
- [ ] P1-03: Tạo schema.sql đủ 10 bảng trong contracts/database.md, khóa ngoại/ràng buộc/index. Không cần triển khai hết chức năng 10 bảng ở tuần 11. Cung cấp lệnh chạy schema và seed trên DB trống.
- [ ] P1-04: Seed 20 nhan đề, 40 bản, 10 bạn đọc và các tài khoản mẫu. Giữ ID đầu tiên theo demo-ids.json. Tạo dữ liệu thẻ hợp lệ/hết hạn/bị khóa/nợ phạt, phiếu đang mượn; ngày seed tính theo ngày chạy để demo không tự hết hạn. Mật khẩu demo phải được băm.
- [ ] P1-05: Làm POST /api/v1/auth/dang-nhap và middleware JWT/role. Xuất req.nguoiDung = {id, vaiTro}; kiểm tra tài khoản khóa, không trả password hash.
- [ ] P1-06: Làm GET /api/v1/sach, GET /api/v1/sach/:id, GET /api/v1/ban-doc và GET /health đúng OpenAPI. SQL tham số hóa; danh sách sách tính số bản TOT + RANH. API bạn đọc chỉ ADMIN/THU_THU.
- [ ] P1-07: Tạo backend/src/modules/loans/index.js xuất một Express Router. Mount sẵn tại /api/v1 trong app.js. Đặt route POST /phieu-muon và GET /ban-doc/toi/dang-muon kiểm tra auth/role rồi trả 501 CHUC_NANG_CHUA_TICH_HOP. Người 2 sẽ thay nội dung module; backend của bạn vẫn phải khởi động độc lập.
- [ ] P1-08: Cung cấp backend/src/db.js xuất pool của pg; transaction sau này dùng một client từ pool.connect(). Không tự tạo client nghiệp vụ riêng cho người 2.
- [ ] P1-09: Deploy backend nền tảng lên Render, cấu hình Supabase theo hướng dẫn kết nối của đề, ghi URL HTTPS và tài khoản demo vào handoff. Không phụ thuộc vào module chưa có của người 2.
- [ ] P1-10: Kiểm thử, ghi kết quả, push member1/backend và viết handoff/member1.md. Cố định commit code bàn giao và giữ dữ liệu demo để người 2 chạy lại.

## Điều kiện hoàn thành

- [ ] Clone sạch, npm ci và dựng schema/seed từ đầu chạy được.
- [ ] Bốn API nghiệp vụ nền tảng chạy thật trên Render; /health hoạt động.
- [ ] Phản hồi khớp OpenAPI; mẫu ID demo tồn tại; mật khẩu được băm.
- [ ] Auth thiếu token/sai quyền bị chặn; list bạn đọc không bị lộ cho BAN_DOC.
- [ ] Hai route chờ người 2 trả 501 có chủ đích, không trả thành công với dữ liệu giả.
- [ ] Đủ schema, seed, cấu hình mẫu, hướng dẫn và commit trên GitHub để người 2 nhận mà không cần bạn giải thích miệng.

Người 2 sẽ tiếp quản module loans, kiểm thử, tích hợp và deploy bản hoàn thiện. Bạn không phải làm API cho mượn, trả sách, gia hạn, hàng đợi, phạt hoặc báo cáo trong gói tuần 11 này.
