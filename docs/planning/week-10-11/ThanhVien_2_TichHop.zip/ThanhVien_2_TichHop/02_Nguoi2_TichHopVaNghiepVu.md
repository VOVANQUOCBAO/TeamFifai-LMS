# Người 2 - Bạn: nhận code sau cùng, ghép và hoàn thành nghiệp vụ

## Khi nào bạn bắt đầu phần code

Bắt đầu sau khi người 1, 3, 4 đã push các nhánh và gửi handoff. Bộ contracts/ đã được cung cấp trước để họ tự triển khai; họ không cần chờ bạn viết service hoặc thiết kế bảng.

Bạn sở hữu backend/src/modules/loans/, kiểm thử tích hợp, docs/integration/ và cấu hình deploy của bản tích hợp. Các thay đổi trên app ưu tiên giới hạn ở cấu hình chế độ/URL; lỗi bàn giao vẫn cần sửa hoặc yêu cầu người sở hữu sửa, không mặc định mọi nhánh đã hoạt động chỉ vì merge thành công.

## Task nhận và ghép

- [ ] P2-01: Nhận branch/commit code/handoff của người 1, 3, 4. Chạy kiểm tra manifest, đối chiếu phiên bản hợp đồng và phạm vi file mỗi người sửa.
- [ ] P2-02: Fetch GitHub, tạo member2/integration từ main và merge lần lượt member1/backend, member3/android, member4/flutter. Giữ lịch sử tác giả. Xem 05_QuyTrinhGitHubVaNghiemThu.md.
- [ ] P2-03: Từ code đã ghép, npm ci, dựng lại DB thử bằng schema/seed của người 1 và thử login/sách/chi tiết/bạn đọc. Build thử hai app theo hướng dẫn handoff trước khi thêm nghiệp vụ để phân biệt lỗi có sẵn và lỗi mới.

## Task hoàn thành phần của bạn

- [ ] P2-04: Thay router 501 trong backend/src/modules/loans/index.js bằng nghiệp vụ thật, giữ nguyên giao diện API đã chốt; dùng req.nguoiDung và pool từ nền tảng người 1.
- [ ] P2-05: POST /api/v1/phieu-muon: nhận banDocId/banSachId; kiểm tra quyền nhân viên, thẻ, trạng thái bạn đọc, nợ phạt, giới hạn số phiếu đang mở và bản TOT + RANH. Backend tính thời điểm mượn/hạn trả theo policies.json.
- [ ] P2-06: Trong một transaction trên cùng pg client, khóa bạn đọc rồi bản sách theo thứ tự cố định, kiểm tra lại điều kiện, ghi phieu_muon, đổi ban_sach thành DANG_MUON và ghi nhat_ky_thu_vien. Rollback toàn bộ nếu lỗi. Ràng buộc DB ngăn hai phiếu đang mở cùng bản sách phải có từ schema của người 1.
- [ ] P2-07: GET /api/v1/ban-doc/toi/dang-muon: lấy ban_doc từ user ID trong JWT, trả đúng phiếu của mình với nhanDe, maCaBiet, hanTra; phân trang đúng hợp đồng. Không nhận ID bạn đọc tùy ý từ app để quyết định dữ liệu cá nhân.
- [ ] P2-08: Giữ nguyên schema cơ sở. Nếu phát hiện cần bổ sung index/ràng buộc, tạo migration mới có số tăng dần và cập nhật schema tổng hợp; không sửa seed để che lỗi nghiệp vụ hoặc đổi ID demo đang dùng.
- [ ] P2-09: Chạy integration test API; đổi APP_MODE=live và API_BASE_URL của hai app sang backend tích hợp, build lại. Android phải gửi được form mượn có sẵn; Flutter phải tải được danh sách đang mượn mà người 4 đã làm.
- [ ] P2-10: Deploy bản tích hợp từ nhánh/commit đã ghép, xác nhận Render đang chạy đúng commit. Build lại APK live, ghi kết quả kiểm thử và hoàn thiện README demo.
- [ ] P2-11: Push member2/integration; chỉ hợp nhất main sau khi các bước nghiệm thu đã đạt. Ghi rõ tag/commit bản tuần 11 và các việc chuyển sang mốc sau.

## Ca bắt buộc bạn kiểm tra

1. Đăng nhập Android bằng THU_THU, chọn đúng bản RANH và bạn đọc demo, bấm cho mượn: trả 201, có phiếu và trạng thái đổi.
2. Flutter đăng nhập bạn đọc tương ứng, tải lại: thấy đúng phiếu mới; hai app tải lại thấy số bản rảnh giảm.
3. Hai request đồng thời cùng mượn một bản: chỉ một thành công; request còn lại báo xung đột.
4. Một bạn đọc gửi hai yêu cầu ở sát giới hạn: tổng phiếu không vượt giới hạn.
5. Thẻ hết hạn/bị khóa/nợ phạt bị chặn theo mã lỗi; DB không có cập nhật dở dang.
6. BAN_DOC không gọi được API cho mượn hoặc danh sách bạn đọc; không xem được phiếu của tài khoản khác.
7. Sai token/mất mạng/501 trước tích hợp được app xử lý; khi nghiệm thu không còn route nghiệp vụ tuần 11 trả 501.

## Bàn giao cuối tuần 11

Một repo ghép đủ backend + Android + Flutter; URL backend live; 2 APK live cài được; schema/seed dựng lại được; tài liệu API và tài khoản demo; kết quả kiểm thử có thật; commit/tag và lịch sử đóng góp giữ đúng người.

Đây là task tuần 11. Các nghiệp vụ trả, gia hạn, phạt bậc thang, giữ chỗ 48 giờ, nhắc hạn và báo cáo vẫn phải được phân bổ/hoàn thành ở các mốc sau theo đề; chúng không được coi là đã xong chỉ nhờ có bảng DB.
