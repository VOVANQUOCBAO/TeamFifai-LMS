# Thành viên 2 - Coordinator và nghiệp vụ sau cùng

1. Đọc `00_DocTruoc_QuyUocChung.md`.
2. Dùng nguyên bộ `contracts/` v1.0.0; đây là bộ chung giống hệt của cả bốn người.
3. Làm theo `02_Nguoi2_TichHopVaNghiepVu.md`.
4. Đọc `05_QuyTrinhGitHubVaNghiemThu.md` để thao tác đúng nhánh và bàn giao.
5. Đối chiếu PDF đề tài trong thư mục khi cần kiểm tra yêu cầu của giảng viên.

Bạn nhận ba nhánh của người 1, 3, 4 sau khi họ hoàn thành, ghép vào nhánh tích hợp rồi làm nghiệp vụ theo task số 2. File 05 hướng dẫn nhận code và nghiệm thu.

Nhận link repository GitHub và mã nhóm từ người 2 trước khi bắt đầu. Gói này chứa tài liệu giao việc, hợp đồng API/dữ liệu và JSON mẫu để triển khai.
