# Người 4 - Flutter hoàn chỉnh giao diện và kết nối trước khi người 2 nhận

## Đầu vào và phạm vi

Nhận contracts/ v1.0.0 từ commit nền tảng; tạo member4/flutter. Chỉ sửa client-flutter/ và handoff/member4.md. Dùng Flutter 3.35+, Dart 3, http và shared_preferences. Không chờ API đang mượn của người 2.

## Task

- [ ] P4-01: Tạo project; tên app/tên gói có mã nhóm; khóa dependency phù hợp, ghi phiên bản SDK; dựng ApiService/model đúng OpenAPI. Không tự đổi tên trường thành convention riêng.
- [ ] P4-02: Tách repository/interface khỏi widget; có mock implementation đọc fixture trong assets và live implementation gọi HTTP. Mock có nhãn DEMO; live không fallback dữ liệu giả khi lỗi.
- [ ] P4-03: Màn hình 1: đăng nhập Form/validator, dùng Navigator, lưu token bằng shared_preferences và xử lý hết phiên. Luồng Client dùng BAN_DOC.
- [ ] P4-04: Màn hình 2: danh sách/tra cứu sách bằng ListView.builder, hiển thị tên/tác giả/số bản rảnh; ảnh có loadingBuilder/errorBuilder nếu hiển thị ảnh. Dữ liệu mẫu và live cùng model.
- [ ] P4-05: Màn hình 3: danh sách đang mượn gọi GET /ban-doc/toi/dang-muon, hiển thị nhanDe/maCaBiet/hanTra/trangThai, có tải lại. Không bắt người 2 viết thêm màn hình này sau khi nhận code.
- [ ] P4-06: Xử lý tải/rỗng/lỗi/thử lại/401/403/501; kiểm tra mounted sau await khi dùng context. 501 báo chờ tích hợp, không hiển thị dữ liệu giả như đang live.
- [ ] P4-07: Đọc dart-define APP_MODE và API_BASE_URL; người 2 chuyển sang live bằng tham số build. Không cần sửa widget hoặc model để đổi URL.
- [ ] P4-08: Test mock cả 3 màn hình bằng fixture. Khi người 1 có URL thì test login/sách thật; API đang mượn có sẵn live implementation chờ người 2. Chạy flutter analyze không còn lỗi.
- [ ] P4-09: Build APK demo, push member4/flutter, viết handoff/member4.md có commit code, lệnh build mock/live, SDK đã dùng, kết quả analyze/test và mức thử API thật.

## Điều kiện bàn giao

- [ ] Clone sạch, flutter pub get và build APK được.
- [ ] Có đủ 3 màn hình, không còn TODO kết nối API đang mượn để người 2 viết hộ.
- [ ] Người 2 chỉ cần APP_MODE=live và API_BASE_URL rồi build lại.
- [ ] Phiếu mock tương ứng tài khoản bạn đọc demo; không hiển thị phiếu của người khác khi đổi tài khoản.
- [ ] Đã xử lý đủ lỗi/empty/loading, logout xóa token và làm mới dữ liệu cá nhân.
- [ ] Ghi rõ phần đã thử mock/live; không coi mock là minh chứng API thật.

Tuần 11 phần của bạn được bàn giao theo hợp đồng + mock/live wiring; người 2 sẽ chạy luồng mượn xuyên suốt sau khi nhận code. Các tính năng Client còn lại tiếp tục ở mốc sau.
