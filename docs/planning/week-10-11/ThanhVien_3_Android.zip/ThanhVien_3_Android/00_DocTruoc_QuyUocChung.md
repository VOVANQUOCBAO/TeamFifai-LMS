# Quy ước chung v1.0.0 - Tuần 11, đề 21

## Cách làm đã đổi theo yêu cầu

Người số 2 là coordinator và người viết nghiệp vụ sau cùng. Người 1, 3, 4 làm xong phần được giao, commit và push lên các nhánh GitHub riêng. Người 2 nhận các nhánh, ghép mã nguồn rồi hoàn thành API mượn sách, kiểm thử và deploy bản tích hợp.

Ba người 1, 3, 4 không cần chờ người 2 viết backend, thiết kế DB hoặc sửa giao diện cho họ. Mọi người nhận cùng bộ contracts/ trong gói này ngay từ đầu. Công việc dùng API chưa có được phát triển/kiểm tra bằng fixture; tiêu chí chạy thật được nghiệm thu sau khi người 2 tích hợp.

## Phạm vi tuần 11

PDF yêu cầu backend online, ít nhất 3 API thật và 2 màn hình mỗi app; mốc này chiếm 1 điểm, không cho nộp bù. Kế hoạch v2 giao người 1 làm 4 API nghiệp vụ thật ngay trước khi người 2 bắt đầu: đăng nhập, danh sách sách, chi tiết sách và danh sách bạn đọc. Người 2 bổ sung tạo phiếu mượn và danh sách đang mượn của tôi.

Hai app làm 3 màn hình để bạn có thể tích hợp trọn luồng: Android đăng nhập/danh sách sách/cho mượn; Flutter đăng nhập/danh sách sách/đang mượn. Đây là phạm vi nhóm chọn, cao hơn tối thiểu 2 màn hình của tuần 11. Toàn bộ nghiệp vụ cuối kỳ vẫn được phát triển ở các mốc tiếp theo.

## Công nghệ theo PDF

| Phần | Công nghệ |
|---|---|
| Android Admin | Android Studio, Java + XML, minSdk 24; Retrofit 2 + Gson |
| Flutter Client | Flutter 3.35+, Dart 3; chọn http cho kế hoạch này; shared_preferences |
| Backend | Node.js 20 + Express 4, JavaScript, pg và SQL thuần |
| Xác thực | JWT tự phát hành + bcrypt |
| CSDL | PostgreSQL trên Supabase |
| Ảnh/tệp | Supabase Storage khi cần |
| Deploy | Render Web Service |
| Mã nguồn | Một repo GitHub chung, nhánh riêng từng người |

PDF cho phép Android dùng OkHttp thay Retrofit/Gson, Flutter dùng dio thay http và không bắt buộc TypeScript. Để thống nhất, gói này chọn đúng các lựa chọn trong bảng; thành viên không tự đổi. Các phiên bản Node/Express/Flutter được ghi theo đề, không phải khẳng định đó là phiên bản mới nhất.

## Bộ chung duy nhất

- contracts/openapi.yaml: phương thức, URL, request, response, mã HTTP, quyền và schema JSON.
- contracts/database.md: cấu trúc đủ 10 bảng để người 1 triển khai trước.
- contracts/policies.json: phiên bản hợp đồng, vai trò, trạng thái và chính sách demo.
- contracts/demo-ids.json: ID/tài khoản mẫu thống nhất.
- contracts/fixtures/: phản hồi mẫu dùng cho UI và kiểm tra hợp đồng.
- contracts/manifest.json: checksum để nhận biết file hợp đồng bị đổi ngoài quy trình.

contracts/openapi.yaml là nguồn chuẩn của giao tiếp HTTP. docs/api.md và README giải thích/cách chạy, không được định nghĩa một API khác. contracts/database.md là chuẩn DB. Fixture minh họa các schema đã chốt, không thay thế dữ liệu thật khi nghiệm thu.

Mọi thành viên giữ nguyên các file contracts/. Nếu phát hiện cần sửa, báo người 2 xử lý phiên bản hợp đồng và thông báo toàn nhóm. Người 1 được chọn chi tiết index/SQL nội bộ phù hợp, nhưng không tự đổi các cột, ID hoặc ý nghĩa trạng thái đã chốt.

## Cấu trúc repo và phạm vi sửa

```text
repo/
  contracts/                 # Cùng bản v1.0.0 cho cả nhóm
  backend/                   # Người 1 làm nền tảng; người 2 nhận và làm loans
  admin-android/             # Người 3
  client-flutter/            # Người 4
  handoff/member1.md
  handoff/member3.md
  handoff/member4.md
  docs/integration/          # Người 2
```

Người 1 tạo commit khởi đầu chứa bộ contracts/ trên main, gắn tag contract-v1.0.0; sau đó tách nhánh làm backend. Người 3 và 4 lấy cùng commit gốc, tách nhánh và bắt đầu làm app. Việc này chỉ là khởi tạo repo bằng bộ chung đã cung cấp, không đợi người 2 code phần nào.

Nhánh: member1/backend, member3/android, member4/flutter. Người 2 nhận code trên member2/integration. Người 1, 3, 4 chỉ sửa thư mục của mình và file handoff tương ứng. Không chỉnh project/lockfile của người khác hoặc tự ghép code của người khác vào nhánh mình.

Trong PDF, mục B dùng từ nhánh trong khi D.1 yêu cầu 3 thư mục con; kế hoạch này giữ cả 3 thư mục và các nhánh riêng. Đối chiếu LMS nếu lớp có quy định bổ sung.

## Quy ước dữ liệu và kết nối

- API_BASE_URL của hai app kết thúc bằng /api/v1/, ví dụ https://ten-app.onrender.com/api/v1/. Endpoint trong app là sach hoặc auth/dang-nhap, không lặp /api/v1.
- Backend có GET /health riêng. Mọi endpoint khác trong hợp đồng ở /api/v1.
- Giao diện module backend được chốt: db.js dùng module.exports = { pool }; middleware/auth.js dùng module.exports = { xacThuc, choPhep }. xacThuc đặt req.nguoiDung = { id, vaiTro }; choPhep(...vaiTro) trả về middleware kiểm tra quyền. modules/loans/index.js dùng module.exports = router; app.js mount app.use('/api/v1', require('./modules/loans')). Route trong router là /phieu-muon và /ban-doc/toi/dang-muon, không lặp prefix.
- Xác thực Authorization: Bearer <token>. JWT thật dùng sub là nguoi_dung.id, vaiTro và exp; thời hạn demo 24 giờ.
- DB snake_case, JSON camelCase; UUID dạng chuỗi; timestamp ISO 8601 UTC; tiền là số nguyên VNĐ.
- Danh sách trả data là mảng và meta gồm page/pageSize/total; mặc định page=1, pageSize=20, tối đa 100.
- Các trường có thể trống được trả null theo schema; không tự thay bằng chuỗi "null" hoặc bỏ trường bắt buộc.
- Mã lỗi được xử lý qua error.code; error.message dùng để hiển thị.
- ADMIN và THU_THU dùng Android; BAN_DOC dùng Flutter. Quyền vẫn được kiểm tra ở backend.
- SÁCH là nhan đề. BẢN SÁCH là cuốn cụ thể. POST phiếu mượn nhận banSachId; không nhận sachId thay cho nó.

## Hai chế độ của app

Mỗi app có repository/interface truy cập dữ liệu và hai implementation mock/live. Mock đọc bản sao các fixture chung trong assets, không gọi API thật; giao diện hiển thị nhãn DEMO. Live gọi HTTP thật; 501 phải hiện “Chức năng chưa tích hợp”, không âm thầm chuyển sang dữ liệu giả.

Người 3/4 phải bàn giao cả hai implementation. Người 2 chỉ cần đổi cấu hình APP_MODE=live và API_BASE_URL rồi build lại, không phải viết lại DTO, form hoặc request cho họ.

Android đọc Gradle property appMode và apiBaseUrl để tạo BuildConfig. Flutter đọc dart-define APP_MODE và API_BASE_URL. Chỉ dùng hai giá trị mock/live. Mặc định bản demo phát triển có thể là mock; bản nghiệm thu cuối cùng phải được build với live rõ ràng.

## Handoff bắt buộc của người 1, 3, 4

Push nhánh riêng và tạo handoff/memberN.md có: tên nhánh; commit hash code được bàn giao; phạm vi đã xong; lệnh build/chạy; cấu hình cần đặt; kết quả kiểm thử; vị trí APK nếu có; API/module còn chờ người 2; danh sách lỗi đã biết. Handoff chỉ tham chiếu hash của commit code trước đó để tránh vòng lặp tự ghi hash chính nó.

Commit nguồn và hướng dẫn là bắt buộc. APK là bản xem thử đi kèm, không thay thế source. Dùng GitHub riêng của từng người, giữ commit có ý nghĩa; yêu cầu 15 commit trong PDF tính cho cả 8 tuần. Không commit .env, mật khẩu DB, JWT secret hoặc service-role key thật.
