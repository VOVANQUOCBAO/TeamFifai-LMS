# Người 3 - Android hoàn chỉnh giao diện và kết nối trước khi người 2 nhận

## Đầu vào và phạm vi

Nhận contracts/ v1.0.0 từ commit nền tảng; tạo member3/android. Chỉ sửa admin-android/ và handoff/member3.md. Dùng Java + XML, minSdk 24, Retrofit 2 + Gson. Không chờ API mượn sách của người 2.

## Task

- [ ] P3-01: Tạo project có tên app/tên gói/TAG chứa mã nhóm; quyền INTERNET; Gradle wrapper/lockfile và hướng dẫn build có thể chạy lại.
- [ ] P3-02: Viết DTO theo OpenAPI cho login, sách, chi tiết sách, bản sách, bạn đọc, phiếu mượn và error. UUID là String; phân biệt sachId/banSachId.
- [ ] P3-03: Tách repository/interface khỏi Activity/Fragment. Có mock implementation đọc bản sao contracts/fixtures trong assets và live implementation dùng Retrofit. Chế độ mock hiển thị nhãn DEMO; live không âm thầm lấy dữ liệu giả.
- [ ] P3-04: Màn hình 1: đăng nhập Form validation, lưu token, gắn Bearer, xử lý 401/403. Chỉ ADMIN/THU_THU vào Admin.
- [ ] P3-05: Màn hình 2: danh sách sách RecyclerView/Adapter/ViewHolder, tìm kiếm, hiển thị tên/tác giả/số bản rảnh; chọn một nhan đề mở màn hình cho mượn.
- [ ] P3-06: Màn hình 3: lấy chi tiết sách để chọn một banSachId từ danh sách bản; lấy GET /ban-doc để chọn banDocId; gửi đúng POST /phieu-muon. Không hardcode chỉ một ID hoặc tự tính hạn trả. Có kiểm tra form, chặn bấm lặp và hiển thị kết quả/lý do lỗi.
- [ ] P3-07: Hoàn thiện loading/rỗng/lỗi/thử lại, lưu form khi xoay màn hình. API đang trả 501 thì báo chức năng chờ tích hợp, không thông báo mượn thành công.
- [ ] P3-08: Đọc Gradle properties appMode và apiBaseUrl, đưa vào BuildConfig để người 2 build live bằng tham số; không yêu cầu sửa Java/XML mới đổi được chế độ hoặc URL.
- [ ] P3-09: Tự test mock 3 màn hình với fixture. Khi URL người 1 có, test login/sách/chi tiết/bạn đọc thật. Form mượn được nghiệm thu ở mock trước và có sẵn live request chờ người 2; ghi rõ mức đã thử.
- [ ] P3-10: Push member3/android và handoff/member3.md: commit code, SDK/JDK/Gradle đã dùng, lệnh build cả hai chế độ, APK demo, kiểm thử và phần chờ API người 2.

## Điều kiện bàn giao

- [ ] Từ clone sạch build được 3 màn hình; mock form mượn dùng đúng body banDocId + banSachId.
- [ ] Live implementation đã có đủ request/DTO/error mapping kể cả POST mượn; không còn TODO để người 2 viết hộ form hoặc API client.
- [ ] Người 2 chỉ cần cấp API_BASE_URL và appMode=live rồi build lại là app dùng backend thật.
- [ ] Xử lý được các fixture lỗi 400/401/403/409/501; không crash hoặc báo thành công giả.
- [ ] Nếu đã thử API nền tảng người 1 thì ghi kết quả thật; nếu chưa có URL thì ghi “chưa thử live”, không ghi đã đạt.

Tuần 11 phần của bạn được bàn giao theo hợp đồng + mock/live wiring; kết quả tích hợp thật do người 2 kiểm tra sau cùng. Các tính năng Android còn lại của đồ án tiếp tục ở mốc sau.
