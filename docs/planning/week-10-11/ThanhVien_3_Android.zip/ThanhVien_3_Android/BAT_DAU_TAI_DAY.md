# Thành viên 3 - Android Admin

1. Đọc `00_DocTruoc_QuyUocChung.md`.
2. Dùng nguyên bộ `contracts/` v1.0.0; đây là bộ chung giống hệt của cả bốn người.
3. Làm theo `03_Nguoi3_AndroidAdmin.md`.
4. Đọc `05_QuyTrinhGitHubVaNghiemThu.md` để thao tác đúng nhánh và bàn giao.
5. Đối chiếu PDF đề tài trong thư mục khi cần kiểm tra yêu cầu của giảng viên.

Làm phần được giao trên nhánh `member3/android`. Khi hoàn thành, push mã nguồn và file `handoff/member3.md`, rồi gửi tên nhánh và commit bàn giao cho người 2. Người 2 sẽ nhận code, tích hợp và hoàn thành nghiệp vụ sau cùng.

Nhận link repository GitHub và mã nhóm từ người 2 trước khi bắt đầu. Gói này chứa tài liệu giao việc, hợp đồng API/dữ liệu và JSON mẫu để triển khai.
