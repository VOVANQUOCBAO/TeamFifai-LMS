# GitHub và cách người 2 nhận toàn bộ phần đã xong

## Một lần khởi tạo

Người 1 đưa contracts/ v1.0.0 từ gói này lên main của repo chung, gắn tag contract-v1.0.0 và gửi URL repo cho nhóm. Đây là đầu vào chung cho ba người triển khai; người 2 chưa cần viết nghiệp vụ.

Người 1, 3, 4 tạo nhánh từ đúng commit contracts. Các lệnh dưới đây là hướng dẫn, chưa được thực hiện với repo của bạn. Thay URL và tên file/commit theo repo thật. Trước switch/merge, kiểm tra git status; commit hoặc xử lý công việc đang dở trước khi tiếp tục.

## Mỗi người triển khai

```bash
git clone <REPO_URL>
cd <TEN_REPO>
git switch -c member1/backend origin/main
```

Người 3 thay bằng member3/android, người 4 thay bằng member4/flutter. Chỉ git add các file thuộc phạm vi mình; kiểm tra git diff --cached trước commit. Ví dụ cho người 1:

```bash
git add backend handoff/member1.md
git commit -m "Hoan thanh backend nen tang tuan 11"
git push -u origin member1/backend
```

Mỗi người commit tiến độ có ý nghĩa trong quá trình làm; ví dụ cuối chỉ minh họa bước bàn giao. Handoff ghi hash commit code trước commit ghi handoff. Không push đè hoặc ghi thay tên tác giả.

## Người 2 nhận code sau cùng

Khi đã có cả ba handoff, chạy trên working tree sạch và tên nhánh tích hợp chưa tồn tại:

```bash
git fetch origin
git switch -c member2/integration origin/main
git merge --no-ff origin/member1/backend
git merge --no-ff origin/member3/android
git merge --no-ff origin/member4/flutter
```

Kiểm tra mỗi lệnh thành công trước khi chạy lệnh tiếp theo. Nếu có conflict, xem và giải quyết từng file; không chọn ghi đè hàng loạt. Ghi nhận SHA bàn giao đã merge; không lấy thêm commit mới của thành viên trong lúc đang nghiệm thu mà chưa review thay đổi. Sau đó người 2 làm task trong file 02.

Sau khi kiểm thử:

```bash
git add backend docs/integration
git commit -m "Tich hop nghiep vu muon sach va kiem thu tuan 11"
git push -u origin member2/integration
```

Nếu sửa cấu hình app hay tài liệu gốc, stage rõ các file đó sau khi review. Push nhánh tích hợp không tự có nghĩa main/Render đã cập nhật: người 2 hợp nhất bản đã nghiệm thu vào nhánh deploy, xác nhận commit trên Render và build hai APK từ bản này.

## Cấu hình build mà app phải hỗ trợ

Android, trong admin-android trên Windows, thay URL ví dụ bằng URL backend tích hợp:

```powershell
.\gradlew.bat assembleDebug -PappMode=live -PapiBaseUrl=https://ten-app.onrender.com/api/v1/
```

Flutter, trong client-flutter:

```bash
flutter pub get
flutter analyze
flutter build apk --debug --dart-define=APP_MODE=live --dart-define=API_BASE_URL=https://ten-app.onrender.com/api/v1/
```

Người 3/4 phải triển khai cơ chế đọc tham số này và kiểm chứng lệnh trong README của mình; gói tài liệu hiện tại chưa chứa mã app.

## Nghiệm thu cuối cùng của người 2

- [ ] Contract v1.0.0 không bị lệch giữa ba nhánh; source và lockfile build được.
- [ ] Schema/seed chạy trên DB thử trống, đủ ID demo và không chứa secret thật trong repo.
- [ ] Bốn API nền tảng của người 1 và hai API nghiệp vụ người 2 chạy thật; /health hoạt động.
- [ ] Android và Flutter build live, dùng cùng URL, cùng DB; màn hình không còn nhãn DEMO.
- [ ] Android cho mượn bản RANH, Flutter bạn đọc tương ứng nhìn thấy phiếu sau tải lại.
- [ ] Số bản rảnh giảm đúng; hai yêu cầu đồng thời không tạo hai phiếu đang mở cùng bản hoặc vượt giới hạn bạn đọc.
- [ ] Token sai/thiếu quyền/thẻ hết hạn/nợ phạt/mạng lỗi được xử lý đúng.
- [ ] Không có 501 trên các API tuần 11 được giao cho người 2 sau khi hoàn tất tích hợp.
- [ ] Ghi URL, tài khoản từng vai trò, SHA/tag demo, hai APK, hướng dẫn và kết quả kiểm thử vào bản bàn giao cuối.

Mức “đã xong” của từng người trước tích hợp và mức “hệ thống đã chạy thật” được ghi riêng. Người 2 là người xác nhận mức thứ hai.

Tham khảo kỹ thuật: [Git merge](https://git-scm.com/docs/git-merge), [OpenAPI 3.0.3](https://spec.openapis.org/oas/v3.0.3.html).
